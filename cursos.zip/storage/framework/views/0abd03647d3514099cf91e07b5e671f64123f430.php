 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- Portada -->
    <section class="bg-cover" style="background-image: url(<?php echo e(asset('img/homeCourse/agroproductor.jpg')); ?>)">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-36">
            <div class="w-full md:w-3/4 lg:w-1/2">
            <h1 class="text-white font-fold text-4xl">
                Los mejores cursos para agroproductores y consimidores
            </h1>
            <p class="text-white text-lg mt-2 mb-4">Creemos que la educación de los agroproductores y de los consumidores es la clave para una industria agropecuaria más fuerte y próspera</p>
            <!-- component -->
              <!-- This is an example component -->
              <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('Y5XbuK6')) {
    $componentId = $_instance->getRenderedChildComponentId('Y5XbuK6');
    $componentTag = $_instance->getRenderedChildComponentTagName('Y5XbuK6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Y5XbuK6');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('Y5XbuK6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;
        </div>
        </div>
    </section>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('course-index')->html();
} elseif ($_instance->childHasBeenRendered('izuOBdz')) {
    $componentId = $_instance->getRenderedChildComponentId('izuOBdz');
    $componentTag = $_instance->getRenderedChildComponentTagName('izuOBdz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('izuOBdz');
} else {
    $response = \Livewire\Livewire::mount('course-index');
    $html = $response->html();
    $_instance->logRenderedChild('izuOBdz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\xampp2\htdocs\cursos\resources\views/courses/index.blade.php ENDPATH**/ ?>