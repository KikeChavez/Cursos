<?php return array (
  'course-index' => 'App\\Http\\Livewire\\CourseIndex',
  'course-status' => 'App\\Http\\Livewire\\CourseStatus',
  'search' => 'App\\Http\\Livewire\\Search',
);